package service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Lession6_TimMinTrongMangTest {

    Lession6_TimMinTrongMang findMinElement = new Lession6_TimMinTrongMang();

    @Test
    void testFindMinElementWithValidArray() {
        int[] arr = {3, 5, 7, 2, 8, -1};
        int result = findMinElement.findMinElement(arr);
        assertEquals(-1, result, "Phần tử bé nhất không đúng.");
    }

    @Test
    void testFindMinElementWithEmptyArray() {
        int[] arr = {};
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            findMinElement.findMinElement(arr);
        });
        assertEquals("Mảng rỗng, không thể tìm phần tử bé nhất.", exception.getMessage());
    }

    @Test
    void testFindMinElementWithOneElement() {
        int[] arr = {5};
        int result = findMinElement.findMinElement(arr);
        assertEquals(5, result, "Phần tử bé nhất không đúng.");
    }
}