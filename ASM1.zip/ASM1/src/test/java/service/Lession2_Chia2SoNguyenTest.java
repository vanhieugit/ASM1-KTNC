package service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Lession2_Chia2SoNguyenTest {

    Lession2_Chia2SoNguyen lession2_chia2SoNguyen = new Lession2_Chia2SoNguyen();

    @Test
    void test1_chiaDuongChoDuong() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(10, 2);
            assertEquals(5, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test2_chiaAmChoAm() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(-10, -2);
            assertEquals(5, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test3_chiaDuongChoAm() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(10, -2);
            assertEquals(-5, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test4_chiaAmChoDuong() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(-10, 2);
            assertEquals(-5, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test5_chia0ChoDuong() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(0, 2);
            assertEquals(0, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test6_chia0ChoAm() throws Exception{
        try {
            int result = lession2_chia2SoNguyen.chia2SoNguyen(0, -2);
            assertEquals(0, result);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test7_chiaDuongCho0() throws Exception{
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            lession2_chia2SoNguyen.chia2SoNguyen(10, 0);
        });
        assertEquals("Khong the chia cho 0", exception.getMessage());
    }

    @Test
    void test8_chiaAmCho0() throws Exception{
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            lession2_chia2SoNguyen.chia2SoNguyen(-10, 0);
        });
        assertEquals("Khong the chia cho 0", exception.getMessage());
    }
}