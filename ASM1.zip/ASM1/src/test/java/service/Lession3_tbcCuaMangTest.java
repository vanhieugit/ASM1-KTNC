package service;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class Lession3_tbcCuaMangTest {

    Lession3_tbcCuaMang lession3_tbcCuaMang = new Lession3_tbcCuaMang();

    @Test
    void test1_tbcCuaMang() {
        List<Integer> soTrongMang = Arrays.asList(10, 20, 30, 40, 50);
        double result = lession3_tbcCuaMang.tbcMang(soTrongMang);
        assertEquals(30.0, result, "Trung bình cộng k đúng.");
    }

    // Kiểm tra khi danh sách trống, phương thức phải ném ngoại lệ ArithmeticException
    @Test
    void test2_mangRong() {
        List<Integer> soTrongMang = Arrays.asList();
        ArithmeticException exception = assertThrows(ArithmeticException.class, () -> {
            lession3_tbcCuaMang.tbcMang(soTrongMang);
        });
        assertEquals("danh sach trong k the tinh TBC cua mang.", exception.getMessage());
    }
}