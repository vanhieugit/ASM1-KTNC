package service;

import org.junit.jupiter.api.Test;
import org.junit.platform.commons.function.Try;

import static org.junit.jupiter.api.Assertions.*;

class Lession1_Tich2SoNguyenTest {
    private Lession1_Tich2SoNguyen lession1_tich2SoNguyen = new Lession1_Tich2SoNguyen();

    @Test
    void test1_tich2SoDuongNhoNhat() throws Exception{
        try {
            int tich2SoDuongNhoNhat = lession1_tich2SoNguyen.tich2SoNguyen(1, 1);
            assertEquals(1, tich2SoDuongNhoNhat);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test2_tich2SoAmLonNhat() throws Exception{
        try {
            int tich2SoAmLonNhat = lession1_tich2SoNguyen.tich2SoNguyen(-1, -1);
            assertEquals(1, tich2SoAmLonNhat);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test3_tichKhiSoThuNhatBang0() throws Exception{
        try {
            int tichKhiSoThuNhatBang0 = lession1_tich2SoNguyen.tich2SoNguyen(0, 12);
            assertEquals(0, tichKhiSoThuNhatBang0);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test4_tichKhiSoThuHaiBang0() throws Exception{
        try {
            int tichKhiSoThuHaiBang0 = lession1_tich2SoNguyen.tich2SoNguyen(12, 0);
            assertEquals(0, tichKhiSoThuHaiBang0);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test5_tichHaiSoNguyenDuongBinhThuong() throws Exception{
        try {
            int tichHaiSoNguyenDuongBinhThuong = lession1_tich2SoNguyen.tich2SoNguyen(4, 3);
            assertEquals(12, tichHaiSoNguyenDuongBinhThuong);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test6_tichHaiSoNguyenAmBinhThuong() throws Exception{
        try {
            int tichHaiSoNguyenAmBinhThuong = lession1_tich2SoNguyen.tich2SoNguyen(-4, -2);
            assertEquals(8, tichHaiSoNguyenAmBinhThuong);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test7_tichSo1DuongSo2Am() throws Exception{
        try {
            int tichSo1DuongSo2Am = lession1_tich2SoNguyen.tich2SoNguyen(4, -3);
            assertEquals(-12, tichSo1DuongSo2Am);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test8_tichSo1AmSo2Duong() throws Exception{
        try {
            int tichSo1AmSo2Duong = lession1_tich2SoNguyen.tich2SoNguyen(-4, 2);
            assertEquals(-8, tichSo1AmSo2Duong);
        }
        catch (Exception e){
            fail("Error: " + e.getMessage());
        }
    }

    @Test
    void test9_tichTranSoAm() {
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            Lession1_Tich2SoNguyen.tich2SoNguyen(Integer.MAX_VALUE, -2);
        });
        assertEquals("Overflow: Tich qua nho.", exception.getMessage());
    }

    @Test
    void test10_tichTranSoDuong() {
        Exception exception = assertThrows(ArithmeticException.class, () -> {
            Lession1_Tich2SoNguyen.tich2SoNguyen(Integer.MAX_VALUE, 2);
        });
        assertEquals("Overflow: Tich qua lon.", exception.getMessage());
    }
}