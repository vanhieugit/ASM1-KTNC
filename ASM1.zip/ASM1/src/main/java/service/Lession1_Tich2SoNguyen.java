package service;

public class Lession1_Tich2SoNguyen {
    public static int tich2SoNguyen(int a, int b) throws Exception{
        if (a > 0 && b > 0 && a > Integer.MAX_VALUE / b) {
            throw new ArithmeticException("Overflow: Tich qua lon.");
        }

        if (a < 0 && b < 0 && a < Integer.MAX_VALUE / b) {
            throw new ArithmeticException("Overflow: Tich qua lon.");
        }

        if (a > 0 && b < 0 && b < Integer.MIN_VALUE / a) {
            throw new ArithmeticException("Overflow: Tich qua nho.");
        }

        if (a < 0 && b > 0 && a < Integer.MIN_VALUE / b) {
            throw new ArithmeticException("Overflow: Tich qua nho.");
        }

        return a * b;
    }
}
