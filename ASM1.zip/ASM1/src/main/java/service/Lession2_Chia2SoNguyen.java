package service;

public class Lession2_Chia2SoNguyen {

    public static int chia2SoNguyen(int a, int b) throws ArithmeticException  {



        if (b == 0) {
            throw new ArithmeticException("Khong the chia cho 0");
        }

        if (a % b != 0) {
            throw new ArithmeticException("a khong chia het cho b");
        }

        if (a == Integer.MIN_VALUE && b == -1) {
            throw new ArithmeticException("Tran so.");
        }

        return a / b;
    }
}
