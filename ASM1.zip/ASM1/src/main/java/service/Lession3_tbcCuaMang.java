package service;

import java.util.List;

public class Lession3_tbcCuaMang {
    public static double tbcMang(List<Integer> numbers) throws ArithmeticException {
        // Kiểm tra nếu danh sách trống
        if (numbers == null || numbers.isEmpty()) {
            throw new ArithmeticException("danh sach trong k the tinh TBC cua mang.");
        }

        // Tính tổng và chia cho số phần tử
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }

        return (double) sum / numbers.size();
    }
}
