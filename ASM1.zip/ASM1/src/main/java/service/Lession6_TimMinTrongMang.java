package service;

public class Lession6_TimMinTrongMang {
    public static int findMinElement(int[] arr) throws IllegalArgumentException {
        if (arr == null || arr.length == 0) {
            throw new IllegalArgumentException("Mảng rỗng, không thể tìm phần tử bé nhất.");
        }

        int min = arr[0];

        for (int num : arr) {
            if (num < min) {
                min = num;
            }
        }

        return min;
    }

    public static void main(String[] args) {
        try {
            int[] arr = {3, 5, 7, 2, 8, -1}; // Mảng mẫu
            System.out.println("Phần tử bé nhất trong mảng là: " + findMinElement(arr));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
